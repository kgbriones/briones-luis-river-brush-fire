/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;

import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Scout extends Troop{
    private ArrayList<Integer> resourceAmount = new ArrayList<>();
  
    protected Scout(Element e){
        super("Scout", 1, 1, 3, 3, 1, true, true, e);
        resourceAmount.add(0);
        resourceAmount.add(0);
        resourceAmount.add(0);
    }
     
    public void gather(Cell selectTile){
        if("Fish".equals(selectTile.getResource().getName())){
            resourceAmount.set(0, resourceAmount.get(0) + 1);
        }
        
        if("Fruit".equals(selectTile.getResource().getName())){
            resourceAmount.set(1, resourceAmount.get(1) + 1);
        }
        
        if("Wood".equals(selectTile.getResource().getName())){
            resourceAmount.set(2, resourceAmount.get(2) + 1);
        }
    }
    
    public void stockpile(Cell selectTile){
        selectTile.getBuilding().getTotalResource();
    }
}
