/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;

/**
 *
 * @author user
 */
public class Cavalry extends Troop {
    
    public Cavalry(Element e){
        super("Cavalry", 6, 4, 3, 2, 1, true, true, e);
    }
    
        @Override
        public void attack(Cell allySpot, Cell enemySpot){
        boolean killConfirm = false;
        boolean dead = false;
        enemySpot.getTroop().setHp(enemySpot.getTroop().getHp() - allySpot.getTroop().getAtk());
        if(enemySpot.getTroop().getHp() <= allySpot.getTroop().getAtk()){
            enemySpot.setTroop(allySpot.getTroop());
            killConfirm = true;
            allySpot.setTroop(null);
            
        } else{
            allySpot.getTroop().setHp(allySpot.getTroop().getHp() - enemySpot.getTroop().getAtk());
            if(allySpot.getTroop().getHp() <= enemySpot.getTroop().getAtk()){
                allySpot.setTroop(null);
                dead = true;
            }
        }
        }
        
        public void moveAfterAttack(Cell oldSpot, Cell newSpot){
            newSpot.setTroop(this);
            oldSpot.setTroop(null);
        }
    
}
