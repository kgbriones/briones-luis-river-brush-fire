/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;

/**
 *
 * @author user
 */
public class Archer extends Troop {
    
    protected Archer(Element e){
        super("Archer", 5, 3, 2, 3, 3, true, true, e);
    }
    
}
