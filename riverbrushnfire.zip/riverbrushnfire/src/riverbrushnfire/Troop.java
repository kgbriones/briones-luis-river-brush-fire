/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;

/**
 *
 * @author user
 */
public class Troop {
    
    private String name;
    private double maxhp;
    private double hp;
    private double atk;
    private int moveRange;
    private int visionRange;
    private int atkRange;
    private boolean isVisible;
    private boolean isAttackable;
    private Element element;
    
    protected Troop(String n, double h, double a, int mr, int vr, int ar, boolean iv, boolean ia, Element e){
        name = n;
        hp = h;
        maxhp = h;
        atk = a;
        moveRange = mr;
        visionRange = vr;
        atkRange = ar;
        isVisible = iv;
        isAttackable = ia;
        element = e;
    }
    
    public void move(Cell allySpot, Cell newSpot){
        newSpot.setTroop(allySpot.getTroop());
        allySpot.setTroop(null);
    }
    
    public void attack(Cell allySpot, Cell enemySpot){
        boolean killConfirm = false;
        boolean dead = false;
        enemySpot.getTroop().setHp(enemySpot.getTroop().getHp() - allySpot.getTroop().getAtk());
        if(enemySpot.getTroop().getHp() <= allySpot.getTroop().getAtk()){
            enemySpot.setTroop(null);
            killConfirm = true;
        } else{
            allySpot.getTroop().setHp(allySpot.getTroop().getHp() - enemySpot.getTroop().getAtk());
            if(allySpot.getTroop().getHp() <= enemySpot.getTroop().getAtk()){
                allySpot.setTroop(null);
                dead = true;
            }
        }
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the maxhp
     */
    public double getMaxhp() {
        return maxhp;
    }

    /**
     * @param maxhp the maxhp to set
     */
    public void setMaxhp(double maxhp) {
        this.maxhp = maxhp;
    }

    /**
     * @return the hp
     */
    public double getHp() {
        return hp;
    }

    /**
     * @param hp the hp to set
     */
    public void setHp(double hp) {
        this.hp = hp;
    }

    /**
     * @return the atk
     */
    public double getAtk() {
        return atk;
    }

    /**
     * @param atk the atk to set
     */
    public void setAtk(double atk) {
        this.atk = atk;
    }

    /**
     * @return the moveRange
     */
    public int getMoveRange() {
        return moveRange;
    }

    /**
     * @param moveRange the moveRange to set
     */
    public void setMoveRange(int moveRange) {
        this.moveRange = moveRange;
    }

    /**
     * @return the visionRange
     */
    public int getVisionRange() {
        return visionRange;
    }

    /**
     * @param visionRange the visionRange to set
     */
    public void setVisionRange(int visionRange) {
        this.visionRange = visionRange;
    }

    /**
     * @return the atkRange
     */
    public int getAtkRange() {
        return atkRange;
    }

    /**
     * @param atkRange the atkRange to set
     */
    public void setAtkRange(int atkRange) {
        this.atkRange = atkRange;
    }

    /**
     * @return the isVisible
     */
    public boolean isIsVisible() {
        return isVisible;
    }

    /**
     * @param isVisible the isVisible to set
     */
    public void setIsVisible(boolean isVisible) {
        this.isVisible = isVisible;
    }

    /**
     * @return the isAttackable
     */
    public boolean isIsAttackable() {
        return isAttackable;
    }

    /**
     * @param isAttackable the isAttackable to set
     */
    public void setIsAttackable(boolean isAttackable) {
        this.isAttackable = isAttackable;
    }

    /**
     * @return the element
     */
    public Element getElement() {
        return element;
    }

    /**
     * @param element the element to set
     */
    public void setElement(Element element) {
        this.element = element;
    }
}
