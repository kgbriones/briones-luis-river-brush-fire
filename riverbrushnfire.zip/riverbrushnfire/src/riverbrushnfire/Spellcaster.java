/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;
import java.util.ArrayList;
/**
 *
 * @author user
 */
public class Spellcaster extends Troop {
    private static ArrayList<Spell> spellList = new ArrayList<>();
    
    protected Spellcaster(Element e){
        super("Spellcaster", 1, 4, 2, 3, 5, true, true, e);
    }
    
    public void castSpell(int index, Cell c1, Cell c2, Cell c3, Cell c4){
        spellList.get(index).spellEffect(c1);
        spellList.get(index).spellEffect(c2);
        spellList.get(index).spellEffect(c3);
        spellList.get(index).spellEffect(c4);
    }
    
}
