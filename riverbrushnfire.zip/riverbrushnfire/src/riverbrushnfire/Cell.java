/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;

/**
 *
 * @author user
 */
public class Cell {
    
    private Troop troop = null;
    private Resource resource = null;
    private Building building = null;
    
    protected Cell(Troop ct, Resource r, Building b){
        troop = ct;
        resource = r;
        building = b;
    }

    /**
     * @return the troop
     */
    public Troop getTroop() {
        return troop;
    }

    /**
     * @param troop the troop to set
     */
    public void setTroop(Troop troop) {
        this.troop = troop;
    }

    /**
     * @return the resource
     */
    public Resource getResource() {
        return resource;
    }

    /**
     * @param resource the resource to set
     */
    public void setResource(Resource resource) {
        this.resource = resource;
    }

    /**
     * @return the building
     */
    public Building getBuilding() {
        return building;
    }

    /**
     * @param building the building to set
     */
    public void setBuilding(Building building) {
        this.building = building;
    }
    
}
