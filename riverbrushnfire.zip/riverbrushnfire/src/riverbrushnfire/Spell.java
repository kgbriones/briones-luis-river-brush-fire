/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;

/**
 *
 * @author user
 */
public class Spell {
    private String name;
    private Element element;
    protected Spell(String n, Element e){
        name = n;
        element = e;
        
    }
    
    public void spellEffect(Cell selectTile){
        if("Freeze".equals(this.name)){
            selectTile.getTroop().setIsAttackable(false);
        }
        
        if("Overgrowth".equals(this.name)){
            selectTile.getTroop().setIsVisible(false);
        }
        
        if ("Inspire".equals(this.name)){
            selectTile.getTroop().setHp(selectTile.getTroop().getHp() - 2);
        }
    }
    
}
