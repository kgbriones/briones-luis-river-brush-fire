/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;

/**
 *
 * @author user
 */
public class Swordsman extends Troop {
    
    public Swordsman(Element e){
        super("Swordsman", 8, 5, 1, 2, 1, true, true, e);
    }
    
        @Override
        public void attack(Cell allySpot, Cell enemySpot){
        boolean killConfirm = false;
        boolean dead = false;
        enemySpot.getTroop().setHp(enemySpot.getTroop().getHp() - allySpot.getTroop().getAtk());
        if(enemySpot.getTroop().getHp() <= allySpot.getTroop().getAtk()){
            enemySpot.setTroop(allySpot.getTroop());
            killConfirm = true;
            allySpot.setTroop(null);
            
        } else{
            allySpot.getTroop().setHp(allySpot.getTroop().getHp() - enemySpot.getTroop().getAtk());
            if(allySpot.getTroop().getHp() <= enemySpot.getTroop().getAtk()){
                allySpot.setTroop(null);
                dead = true;
            }
        }
        }
        
        
        public void parry(){
            
        }
    
}
