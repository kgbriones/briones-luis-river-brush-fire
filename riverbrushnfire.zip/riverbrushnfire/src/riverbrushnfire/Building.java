/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;

import java.util.ArrayList;

/**
 *
 * @author user
 */
abstract public class Building {

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the tileRange
     */
    public int getTileRange() {
        return tileRange;
    }

    /**
     * @param tileRange the tileRange to set
     */
    public void setTileRange(int tileRange) {
        this.tileRange = tileRange;
    }

    /**
     * @return the totalResource
     */
    public ArrayList<Integer> getTotalResource() {
        return totalResource;
    }

    /**
     * @param totalResource the totalResource to set
     */
    public void setTotalResource(ArrayList<Integer> totalResource) {
        this.totalResource = totalResource;
    }
    private String name;
    private int tileRange;
    private ArrayList<Integer> totalResource = new ArrayList<>();
    protected Building(String n, int tr){
        name = n;
        tileRange = tr;
    }
}
