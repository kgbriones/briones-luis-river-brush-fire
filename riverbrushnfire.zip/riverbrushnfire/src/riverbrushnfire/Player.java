/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package riverbrushnfire;


import java.util.ArrayList;
/**
 *
 * @author user
 */
public class Player {
    private static ArrayList<Player> playerList = new ArrayList<>();
    private ArrayList<Troop> troopList = new ArrayList<>();
    private static ArrayList<Troop> placableTroops = new ArrayList<>();
    private static ArrayList<Troop> possibleTroops = new ArrayList<>();
    
    
    private int outpostAmount = 1;
    protected Player(){
        playerList.add(this);
    }
    
    public void recruitTroop(int index, Cell chosenTile){
        chosenTile.setTroop(placableTroops.get(index));
        troopList.add(placableTroops.get(index));
        
    }
}
